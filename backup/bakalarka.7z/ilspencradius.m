function v = ilspencradius( ivector )
%ILSPENCRADIUS Compute radius of given interval vector.
%   Detailed explanation goes here

v = (sup(ivector) - inf(ivector))/2;
end

