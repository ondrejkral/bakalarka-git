function [ m, n ] = ilspencmatrixdim( A )
%ILSPENCMATRIXDIM Returns matrix dimensions.
%   3D array representation only.

m = length(A(:,1,1));
n = length(A(1,:,1));

end

