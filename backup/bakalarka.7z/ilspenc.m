function v = ilspenc( A, b, p )
%ILSPENC Parametric interval systems solver.

% ILSPENCGETAK, ILSPENCGETBK, ILSPENCMATRIXDIM, ILSPENCMATRIXCENTER,
% ILSPENCBCENTER - reimplement these in caseof testing new representation 
% of parameters' linear dependencies.

% Testing of conditions like spectral radius etc.
% Determining which algorithms or combination of them to use.


end

