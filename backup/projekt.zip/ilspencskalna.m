function v = ilspencskalna( A, b )
%ILSPENCSKALNA Proposition 3.56 in Hladik (?).

I = eye(dim(A));
R = abs(I - A);

v = infsup(-1,1)*((I -R)\abs(b));

end

