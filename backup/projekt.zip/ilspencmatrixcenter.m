function V = ilspencmatrixcenter( A, iparameterVector)
%ILSPENCMATRCENTER Compute matrix at center of parameter vector.
%   This variation for 3D array reprezentation only.

% Computing center of parameter vector.
parameterCenter = ilspenccenter(iparameterVector);

% Allocation of zero matrix with correct size. 
m = length(A(:,1,1));
n = length(A(1,:,1));
V = zeros(m,n);

% Computing matrix at given center of parameter vector.
% 3D array reprezentation only.
for i = 1:length(iparameterVector)
    V = V + A(:,:,i)*parameterCenter(i);
end
end
