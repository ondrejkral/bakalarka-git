function v = ilspencresidual( A, b, p, option )
%ILSENCSKALNA Solving of Skalna (2012) enclosure.

% Inicialization of general variables.
v = NaN;

% Precondition matrix.
Acenter = ilspencmatrixcenter(A,p);
% x-asterisk from Theorem 4.
x = Acenter\ilspencbcenter(b ,p);

[Ares, bres] = ilspencresidualform(A, b, p);

if (nargin ~= 4)
    %ERROR
    return;
else
    switch option
        case 'RUMP'
             y = ilspencrump(Ares, bres, 15);
        case 'SKALNA'
            y = ilspencskalna(Ares, bres);
        otherwise
            % invalid option
            return;
    end
end

v = x + y;
    
end

