function v = ilspenccenter( ivector )
%ILSPENCCENTER Compute center of given interval vector.
%   Detailed explanation goes here

v = (inf(ivector) + sup(ivector))/2;
end

