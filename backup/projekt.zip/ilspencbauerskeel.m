function v = ilspencbauerskeel( A, b, p )
%ILSPENC Bauer-Skeel bounds to parametric interval systems.

% Inicialization of general variables.
dimensions = ilspencmatrixdim(A);
M = zeros(dimensions);
C = zeros(dimensions(1),1);
I = eye(dimensions);

radiusVector = ilspencradius(p);
% Precondition matrix.
Acenter = ilspencmatrixcenter(A,p);
% x-asterisk from Theorem 4.
x = verifylss(Acenter,ilspencbcenter(b ,p));

% Matrix M from Theorem 4.
for k = 1:length(p)
   M = M + radiusVector(k)*abs(Acenter\ilspencgetak(A,k));
end

% Summation in interval enclosure from Theorem 4.
for k = 1:length(p)
    C = C + radiusVector(k)*abs(Acenter\(ilspencgetak(A,k)*x - ilspencgetbk(b,k)));
end

s = verifylss(I - M,C);

v = hull(x - s, x + s);
end

