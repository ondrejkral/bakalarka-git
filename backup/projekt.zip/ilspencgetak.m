function V = ilspencgetak( A, k )
%ILSPENCGETAK Returning matrix of coeficients for k-th parameter.
%   Additional layer for testing repesentation of parameters' linear 
%   dependencies. Because of MATLAB's lazy copying this shouldn't be
%   significant performance overhead.

% Currently using 3D array representation
    V = A(:,:,k);
end

