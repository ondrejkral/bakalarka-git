function v = ilspencbcenter( b, iparameterVector )
%ILSPENCBCENTER Compute right side of linear system at center of parametric
%vector.
%   This variation for 3D array reprezentation only.

% Computing center of parameter vector.
parameterCenter = ilspenccenter(iparameterVector);

% Allocation of zero vector with correct size. 
l = length(b(:,1));
v = zeros(l,1);

% Computing vector at given center of parameter vector.
% 3D array reprezentation only.
for i = 1:length(iparameterVector);
    v = v + b(:,i)*parameterCenter(i);
end
end

