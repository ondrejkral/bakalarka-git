function v = ilspencrump( A, b, p )
%ILSPENCRUMP Bounds to parametric interval systems in Rump(2010).

% Inicialization of general variables.
dimensions = ilspencmatrixdim(A);
M = zeros(dimensions);
C = zeros(dimensions(1),1);
I = eye(dimensions);

% Precondition matrix.
Acenter = ilspencmatrixcenter(A,p);
% x-asterisk from Theorem 4.
x = Acenter\ilspencbcenter(b ,p);

for k = 1:length(p)
    M = M + (Acenter\ilspencgetak(A,k))*p(k);
end

R = abs(I - M);

for k = 1:length(p)
    C = C + (Acenter\(ilspencgetbk(b,k) - ilspencgetak(A,k)*x))*p(k);
end

v = x + infsup(-1,1)*((I - R)\abs(C));


end

